package com.xiaotro.assistant

import com.google.mlkit.vision.face.Face

/**
 * Phân loại biểu cảm ĐƠN GIẢN dựa trên xác suất cười và trạng thái mắt do
 * Google ML Kit Face Detection trả về. Đây là suy đoán tương đối (heuristic),
 * không phải phân tích cảm xúc chuyên sâu — đủ dùng để trợ lý phản hồi tự
 * nhiên hơn, không nên dùng cho mục đích chẩn đoán tâm lý nghiêm túc.
 */
object FaceMoodAnalyzer {
    fun classifyMood(face: Face): String {
        val smiling = face.smilingProbability ?: -1f
        val leftEye = face.leftEyeOpenProbability ?: -1f
        val rightEye = face.rightEyeOpenProbability ?: -1f
        val eyesOpen = if (leftEye >= 0f && rightEye >= 0f) (leftEye + rightEye) / 2f else -1f

        return when {
            smiling >= 0.7f -> "vui vẻ, đang cười tươi"
            eyesOpen in 0f..0.3f -> "có vẻ buồn ngủ hoặc mệt mỏi"
            smiling in 0f..0.2f && eyesOpen > 0.5f -> "nghiêm túc, ít biểu cảm"
            else -> "bình thường, trung tính"
        }
    }
}
