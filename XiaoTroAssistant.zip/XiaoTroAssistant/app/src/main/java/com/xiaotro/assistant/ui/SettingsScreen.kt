package com.xiaotro.assistant.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.xiaotro.assistant.AppPreferences

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val context = LocalContext.current

    var geminiKey by remember { mutableStateOf(AppPreferences.geminiKey(context)) }
    var picovoiceKey by remember { mutableStateOf(AppPreferences.picovoiceKey(context)) }
    var useCloudTts by remember { mutableStateOf(AppPreferences.useCloudTts(context)) }
    var cloudTtsKey by remember { mutableStateOf(AppPreferences.cloudTtsKey(context)) }
    var cloudTtsVoice by remember { mutableStateOf(AppPreferences.cloudTtsVoice(context)) }
    var savedMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Cài đặt") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Quay lại")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Kết nối AI", style = MaterialTheme.typography.titleMedium)

            OutlinedTextField(
                value = geminiKey,
                onValueChange = { geminiKey = it },
                label = { Text("Gemini API key") },
                supportingText = { Text("Lấy miễn phí tại aistudio.google.com/apikey") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = picovoiceKey,
                onValueChange = { picovoiceKey = it },
                label = { Text("Picovoice access key (từ khóa đánh thức)") },
                supportingText = { Text("Lấy miễn phí tại console.picovoice.ai") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Divider()

            Text("Giọng đọc", style = MaterialTheme.typography.titleMedium)

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Dùng giọng chất lượng cao (Google Cloud TTS)")
                    Text(
                        "Cần bật billing trên Google Cloud (miễn phí trong hạn mức)",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(checked = useCloudTts, onCheckedChange = { useCloudTts = it })
            }

            if (useCloudTts) {
                OutlinedTextField(
                    value = cloudTtsKey,
                    onValueChange = { cloudTtsKey = it },
                    label = { Text("Cloud Text-to-Speech API key") },
                    supportingText = { Text("Bật \"Cloud Text-to-Speech API\" trong Google Cloud Console") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = cloudTtsVoice,
                    onValueChange = { cloudTtsVoice = it },
                    label = { Text("Tên giọng đọc") },
                    supportingText = { Text("Ví dụ: vi-VN-Wavenet-A, vi-VN-Wavenet-C, vi-VN-Neural2-A") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Text(
                    "Đang dùng giọng đọc mặc định có sẵn của Android (miễn phí, không cần key).",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(Modifier.height(8.dp))

            Button(
                onClick = {
                    AppPreferences.setGeminiKey(context, geminiKey)
                    AppPreferences.setPicovoiceKey(context, picovoiceKey)
                    AppPreferences.setUseCloudTts(context, useCloudTts)
                    AppPreferences.setCloudTtsKey(context, cloudTtsKey)
                    AppPreferences.setCloudTtsVoice(context, cloudTtsVoice)
                    savedMessage = "Đã lưu."
                    onSaved()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Lưu")
            }

            savedMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.primary)
            }

            Divider()

            Text("Dữ liệu khuôn mặt", style = MaterialTheme.typography.titleMedium)
            val hasOwnerFace = AppPreferences.hasOwnerFace(context)
            Text(
                if (hasOwnerFace) "Đã ghi nhớ khuôn mặt chủ nhân."
                else "Chưa ghi nhớ khuôn mặt nào. Vào màn hình Camera và bấm \"Ghi nhớ đây là tôi\".",
                style = MaterialTheme.typography.bodySmall
            )
            if (hasOwnerFace) {
                OutlinedButton(
                    onClick = {
                        AppPreferences.clearOwnerFace(context)
                        savedMessage = "Đã xoá dữ liệu khuôn mặt."
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Xoá khuôn mặt đã ghi nhớ")
                }
            }
        }
    }
}
