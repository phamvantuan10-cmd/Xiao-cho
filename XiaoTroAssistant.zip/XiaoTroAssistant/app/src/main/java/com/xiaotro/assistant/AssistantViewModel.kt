package com.xiaotro.assistant

import android.app.Application
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.xiaotro.assistant.network.CloudTtsRepository
import com.xiaotro.assistant.network.GeminiRepository
import com.xiaotro.assistant.service.AssistantEvents
import com.xiaotro.assistant.service.CloudTtsPlayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

enum class AssistantState { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

/** Kết quả cụ thể của việc ghi nhớ khuôn mặt chủ nhân — giúp báo đúng lỗi thay vì chung chung. */
enum class EnrollResult { SUCCESS, MODEL_NOT_LOADED, NO_FACE_DETECTED, EMBEDDING_FAILED }

data class ChatMessage(val isUser: Boolean, val text: String)

data class AssistantUiState(
    val state: AssistantState = AssistantState.IDLE,
    val messages: List<ChatMessage> = emptyList(),
    val errorText: String? = null,
    val cameraRequestId: Int = 0, // tăng lên mỗi khi cần mở màn hình camera (do lệnh giọng nói)
    val continuousActive: Boolean = false // đang trong chế độ nghe liên tục hay không
)

class AssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(AssistantUiState())
    val uiState: StateFlow<AssistantUiState> = _uiState

    private val context get() = getApplication<Application>()

    private val geminiRepository = GeminiRepository(context)
    private val cloudTtsRepository = CloudTtsRepository(context)
    private val faceEmbedder by lazy { FaceEmbedder(context) }

    private var speechRecognizer: SpeechRecognizer? = null
    private var androidTts: TextToSpeech? = null
    private var androidTtsReady = false
    private var isMicBeepMuted = false

    /**
     * Tắt tạm tiếng "bíp" hệ thống phát ra mỗi lần mic bật lên nghe — CHỈ áp
     * dụng khi Xiao không đang nói (silent = false), vì âm bíp và giọng Xiao
     * dùng chung 1 kênh âm thanh (STREAM_MUSIC); tắt lúc Xiao đang nói sẽ làm
     * câm luôn giọng nói.
     * Một số máy (đặc biệt Samsung/Xiaomi/Oppo...) phát âm báo này trên kênh
     * NOTIFICATION hoặc SYSTEM thay vì MUSIC, nên tắt luôn cả 3 kênh cho chắc.
     * Bọc try/catch vì 1 số máy chặn quyền chỉnh âm lượng kênh SYSTEM/NOTIFICATION
     * (yêu cầu quyền Do Not Disturb) — lỗi thì bỏ qua, không làm crash app.
     */
    private fun setMicBeepMuted(mute: Boolean) {
        if (mute == isMicBeepMuted) return
        val audioManager = context.getSystemService(Application.AUDIO_SERVICE) as? AudioManager ?: return
        val direction = if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
        for (stream in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
            try {
                audioManager.adjustStreamVolume(stream, direction, 0)
            } catch (e: SecurityException) {
                // Máy chặn quyền chỉnh kênh này (thường do chính sách Không làm phiền) -> bỏ qua
            }
        }
        isMicBeepMuted = mute
    }

    init {
        // Khởi tạo sẵn SpeechRecognizer ngay từ đầu (không đợi tới lúc cần mới tạo)
        // để loại bỏ độ trễ ~1 giây do lần đầu kết nối tới dịch vụ nhận diện giọng nói.
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)

        androidTts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                androidTts?.language = Locale("vi", "VN")
                androidTts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        // Bắt đầu nghe ngầm ngay khi Xiao bắt đầu nói -> cho phép
                        // ngắt lời tức thì, không cần đợi nói xong mới mở mic.
                        startListeningForCommand(silent = true)
                    }
                    override fun onDone(utteranceId: String?) {
                        _uiState.update { it.copy(state = AssistantState.IDLE) }
                        relistenSoon()
                    }
                    @Deprecated("Deprecated in API")
                    override fun onError(utteranceId: String?) {
                        _uiState.update { it.copy(state = AssistantState.IDLE) }
                    }
                })
                androidTtsReady = true
            }
        }

        // Lắng nghe sự kiện "đã phát hiện từ khóa đánh thức" từ WakeWordService.
        // Nếu trợ lý đang nói, nói từ khóa lần nữa = NGẮT LỜI rồi bắt đầu nghe câu hỏi mới
        // (giống cách dùng thật của Xiaozhi / loa thông minh).
        viewModelScope.launch {
            AssistantEvents.wakeWordDetected.collect {
                interruptIfSpeaking()
                setContinuousActive(true)
                startListeningForCommand()
            }
        }
    }

    /**
     * Bấm nút mic thủ công:
     * - Đang nói -> ngắt lời rồi bật chế độ nghe liên tục
     * - Đang trong chế độ nghe liên tục -> bấm để TẮT hẳn (dừng vòng lặp)
     * - Còn lại -> bật chế độ nghe liên tục
     */
    fun onPrimaryButtonClick() {
        if (_uiState.value.state == AssistantState.SPEAKING) {
            interruptIfSpeaking()
            setContinuousActive(true)
            startListeningForCommand()
            return
        }

        if (_uiState.value.continuousActive) {
            // Đang nghe liên tục -> bấm để dừng hẳn
            setContinuousActive(false)
            speechRecognizer?.cancel()
            _uiState.update { it.copy(state = AssistantState.IDLE) }
        } else {
            setContinuousActive(true)
            startListeningForCommand()
        }
    }

    private fun setContinuousActive(active: Boolean) {
        _uiState.update { it.copy(continuousActive = active) }
    }

    /** Dừng ngay phần trả lời đang đọc (Cloud TTS hoặc Android TTS), dùng cho barge-in. */
    private fun interruptIfSpeaking() {
        androidTts?.stop()
        CloudTtsPlayer.stop()
        _uiState.update { it.copy(state = AssistantState.IDLE) }
    }

    /**
     * @param silent nếu true: bắt đầu nghe NGẦM (không đổi UI sang "Đang nghe"),
     * dùng để nghe song song trong lúc Xiao đang nói — cho phép ngắt lời tức thì
     * thay vì phải đợi Xiao nói xong mới mở mic lại.
     */
    fun startListeningForCommand(silent: Boolean = false) {
        if (_uiState.value.state == AssistantState.LISTENING) return

        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            // Rút ngắn thời gian chờ im lặng trước khi coi như người dùng nói xong,
            // giúp trợ lý phản hồi nhanh hơn sau khi bạn dứt câu.
            putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 500L)
            putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 500L)
        }

        if (!silent) {
            _uiState.update { it.copy(state = AssistantState.LISTENING, errorText = null) }
            setMicBeepMuted(true) // không có TTS đang phát -> tắt được tiếng bíp an toàn
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle) {
                setMicBeepMuted(false)
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()
                if (text.isNullOrBlank()) {
                    if (_uiState.value.continuousActive) {
                        relistenSoon()
                    } else if (_uiState.value.state != AssistantState.SPEAKING) {
                        _uiState.update { it.copy(state = AssistantState.IDLE) }
                    }
                } else {
                    // Bắt được câu nói mới -> NGẮT LỜI ngay lập tức (nếu đang nói) rồi xử lý luôn.
                    // Đây chính là cơ chế "vừa nói vừa nghe": mic đã chạy ngầm từ lúc Xiao
                    // bắt đầu nói, nên vừa bạn cắt ngang là xử lý được ngay, không cần chờ.
                    interruptIfSpeaking()
                    handleUserUtterance(text)
                }
            }

            override fun onError(error: Int) {
                setMicBeepMuted(false)
                if (_uiState.value.continuousActive) {
                    // Đang ở chế độ nghe liên tục -> không dừng, chỉ nghe lại sau 1 chút
                    // (im lặng/không nghe rõ là bình thường, không coi là lỗi cần báo).
                    relistenSoon()
                } else if (_uiState.value.state != AssistantState.SPEAKING) {
                    _uiState.update {
                        it.copy(state = AssistantState.IDLE, errorText = "Không nghe rõ, thử lại nhé (mã lỗi $error)")
                    }
                }
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    private fun handleUserUtterance(text: String) {
        _uiState.update {
            it.copy(messages = it.messages + ChatMessage(isUser = true, text = text))
        }

        // Kiểm tra lệnh cục bộ trước (mở nhạc, dừng nhạc...) — xử lý ngay, không tốn API call
        val command = CommandRouter.handle(context, text)
        if (command.handled) {
            _uiState.update {
                it.copy(
                    state = AssistantState.SPEAKING,
                    messages = it.messages + ChatMessage(isUser = false, text = command.spokenReply)
                )
            }
            speak(command.spokenReply)
            if (command.action == CommandAction.OPEN_CAMERA) {
                _uiState.update { it.copy(cameraRequestId = it.cameraRequestId + 1) }
            }
            return
        }

        _uiState.update { it.copy(state = AssistantState.THINKING) }

        viewModelScope.launch {
            try {
                val reply = geminiRepository.ask(text)
                _uiState.update {
                    it.copy(
                        state = AssistantState.SPEAKING,
                        messages = it.messages + ChatMessage(isUser = false, text = reply)
                    )
                }
                speak(reply)
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(state = AssistantState.ERROR, errorText = "Lỗi: ${e.message}")
                }
            }
        }
    }

    private fun speak(text: String) {
        val useCloud = AppPreferences.useCloudTts(context) && AppPreferences.cloudTtsKey(context).isNotBlank()

        if (useCloud) {
            viewModelScope.launch {
                try {
                    val file = cloudTtsRepository.synthesizeToFile(text)
                    // Bắt đầu nghe ngầm ngay khi audio bắt đầu phát -> cho phép ngắt lời tức thì.
                    startListeningForCommand(silent = true)
                    CloudTtsPlayer.play(
                        file = file,
                        onDone = {
                            _uiState.update { it.copy(state = AssistantState.IDLE) }
                            relistenSoon()
                        },
                        onError = { speakWithAndroidTts(text) } // fallback nếu Cloud TTS lỗi
                    )
                } catch (e: Exception) {
                    speakWithAndroidTts(text) // fallback nếu gọi API lỗi (vd chưa có key)
                }
            }
        } else {
            speakWithAndroidTts(text)
        }
    }

    private fun speakWithAndroidTts(text: String) {
        if (androidTtsReady) {
            androidTts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "assistant_reply")
        } else {
            _uiState.update { it.copy(state = AssistantState.IDLE) }
        }
    }

    /**
     * Nghe lại sau 1 khoảng ngắn. Nếu Xiao vẫn đang nói (phiên nghe ngầm vừa hết
     * hạn giữa chừng), không đổi UI và chỉ âm thầm mở phiên nghe ngầm mới để
     * duy trì khả năng ngắt lời xuyên suốt lúc đang nói. Nếu Xiao đã nói xong,
     * xử lý bình thường như nghe liên tục sau mỗi câu trả lời.
     */
    private fun relistenSoon() {
        val stillSpeaking = _uiState.value.state == AssistantState.SPEAKING
        if (!stillSpeaking) {
            _uiState.update { it.copy(state = AssistantState.IDLE) }
        }
        viewModelScope.launch {
            delay(300)
            if (_uiState.value.continuousActive || stillSpeaking) {
                startListeningForCommand(silent = stillSpeaking)
            }
        }
    }

    /** Mở màn hình camera thủ công (bấm icon camera trên thanh trên). */
    fun requestOpenCamera() {
        _uiState.update { it.copy(cameraRequestId = it.cameraRequestId + 1) }
    }

    /**
     * Gọi khi camera vừa tự động phát hiện + chụp được 1 khuôn mặt.
     * Nếu có model nhận diện danh tính (FaceEmbedder) và đã ghi nhớ khuôn mặt chủ
     * nhân trước đó, so khớp để biết đây có phải chủ nhân không, rồi kết hợp với
     * biểu cảm khuôn mặt để nhờ Gemini tạo lời chào tự nhiên, phù hợp ngữ cảnh.
     */
    /**
     * Gọi khi camera vừa tự động phát hiện + chụp được 1 khuôn mặt.
     * CHỈ giao tiếp (gọi Gemini + chào hỏi) nếu xác nhận ĐÚNG là chủ nhân đã
     * ghi nhớ trước đó — người lạ hoặc trường hợp chưa xác định được danh tính
     * sẽ KHÔNG kích hoạt AI trả lời gì cả (im lặng, không tốn API call).
     */
    fun handleCameraGreeting(moodLabel: String, faceBitmap: android.graphics.Bitmap?) {
        viewModelScope.launch {
            var isOwner = false

            if (faceBitmap != null && faceEmbedder.isAvailable) {
                val croppedFace = FaceCropper.cropToFace(faceBitmap) ?: faceBitmap
                val embedding = faceEmbedder.embed(croppedFace)
                val ownerEmbedding = AppPreferences.ownerFaceEmbedding(context)
                if (embedding != null && ownerEmbedding != null) {
                    isOwner = FaceEmbedder.cosineSimilarity(embedding, ownerEmbedding) > FaceEmbedder.MATCH_THRESHOLD
                }
            }

            if (!isOwner) {
                // Không phải chủ nhân (hoặc chưa xác định được) -> im lặng, không giao tiếp
                _uiState.update {
                    it.copy(
                        state = AssistantState.IDLE,
                        errorText = "Không nhận ra chủ nhân nên Xiao chưa chào — hãy chắc chắn đã \"Ghi nhớ đây là tôi\" trước đó"
                    )
                }
                return@launch
            }

            val prompt = "[Ngữ cảnh riêng, không phải lời người dùng nói: camera vừa tự động chụp và " +
                "xác nhận ĐÚNG đây là chủ nhân. Biểu cảm khuôn mặt hiện tại: $moodLabel.] " +
                "Hãy chào hỏi thật tự nhiên, ngắn gọn (1-2 câu), thân mật như đang chào người quen thuộc, " +
                "phù hợp với biểu cảm vừa nêu."

            _uiState.update {
                it.copy(
                    state = AssistantState.THINKING,
                    messages = it.messages + ChatMessage(isUser = true, text = "📷 (Camera tự động chào hỏi)")
                )
            }

            try {
                val reply = geminiRepository.ask(prompt)
                _uiState.update {
                    it.copy(
                        state = AssistantState.SPEAKING,
                        messages = it.messages + ChatMessage(isUser = false, text = reply)
                    )
                }
                speak(reply)
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(state = AssistantState.ERROR, errorText = "Lỗi: ${e.message}")
                }
            }
        }
    }

    /**
     * Lưu khuôn mặt hiện tại làm "chủ nhân" để lần sau camera nhận ra bạn.
     * Cắt riêng vùng khuôn mặt trước khi tạo "vân tay" nhận diện, giúp so khớp
     * chính xác hơn nhiều so với dùng nguyên cả tấm ảnh.
     * Trả kết quả CỤ THỂ qua onResult (EnrollResult) để biết chính xác lỗi ở
     * bước nào, thay vì chỉ báo chung chung "thất bại".
     */
    fun enrollOwnerFace(faceBitmap: android.graphics.Bitmap, onResult: (EnrollResult, String?) -> Unit) {
        viewModelScope.launch {
            if (!faceEmbedder.isAvailable) {
                val detail = faceEmbedder.lastError
                _uiState.update { it.copy(state = AssistantState.ERROR, errorText = "LỖI MODEL: ${detail ?: "không rõ nguyên nhân"}") }
                onResult(EnrollResult.MODEL_NOT_LOADED, detail)
                return@launch
            }
            val croppedFace = FaceCropper.cropToFace(faceBitmap)
            if (croppedFace == null) {
                onResult(EnrollResult.NO_FACE_DETECTED, null)
                return@launch
            }
            val embedding = faceEmbedder.embed(croppedFace)
            if (embedding == null) {
                onResult(EnrollResult.EMBEDDING_FAILED, null)
                return@launch
            }
            AppPreferences.setOwnerFaceEmbedding(context, embedding)
            onResult(EnrollResult.SUCCESS, null)
        }
    }

    override fun onCleared() {
        setMicBeepMuted(false)
        speechRecognizer?.destroy()
        androidTts?.stop()
        androidTts?.shutdown()
        CloudTtsPlayer.stop()
        super.onCleared()
    }
}
