package com.xiaotro.assistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.MediaStore
import android.view.KeyEvent
import java.util.Locale

enum class CommandAction { NONE, OPEN_CAMERA }

data class CommandResult(
    val handled: Boolean,
    val spokenReply: String = "",
    val action: CommandAction = CommandAction.NONE
)

/**
 * Kiểm tra câu nói của người dùng có khớp lệnh điều khiển cục bộ không
 * (nhạc, đèn pin, mở app, gọi điện...). Nếu khớp -> xử lý ngay trên máy,
 * KHÔNG gửi lên Gemini -> phản hồi nhanh hơn nhiều và tiết kiệm quota API.
 * Nếu không khớp lệnh nào -> trả handled = false để ViewModel gửi tiếp cho Gemini.
 *
 * THỨ TỰ KIỂM TRA quan trọng: các lệnh cụ thể (nhạc, đèn pin, gọi điện) được
 * kiểm tra TRƯỚC lệnh "mở app" chung chung, để "mở nhạc" / "mở đèn pin" không
 * bị hiểu nhầm thành "mở app tên là 'nhạc'/'đèn pin'".
 */
object CommandRouter {

    private val PLAY_PATTERNS = listOf("mở nhạc", "phát nhạc", "bật nhạc", "nghe nhạc", "mở bài hát")
    private val PAUSE_PATTERNS = listOf("dừng nhạc", "tắt nhạc", "tạm dừng nhạc", "ngừng nhạc")
    private val RESUME_PATTERNS = listOf("tiếp tục nhạc", "phát tiếp", "chạy tiếp nhạc")
    private val NEXT_PATTERNS = listOf("bài tiếp theo", "chuyển bài", "next bài", "đổi bài")
    private val PREV_PATTERNS = listOf("bài trước", "quay lại bài trước")

    private val FLASH_ON_PATTERNS = listOf("bật đèn pin", "mở đèn pin", "bật đèn flash", "bật flash")
    private val FLASH_OFF_PATTERNS = listOf("tắt đèn pin", "tắt đèn flash", "tắt flash")

    private val CAMERA_PATTERNS = listOf(
        "mở camera", "bật camera", "nhìn xem ai đây", "chào tôi đi",
        "nhận diện khuôn mặt", "xem mặt tôi", "nhìn tôi đi"
    )

    private val CALL_NUMBER_PATTERNS = listOf("gọi điện số", "gọi số điện thoại", "gọi điện thoại số", "gọi số", "gọi tới số")

    private val OPEN_DIALER_PATTERNS = listOf("mở trình gọi", "mở bàn phím gọi", "mở điện thoại", "mở màn hình gọi")
    private val OPEN_CONTACTS_PATTERNS = listOf("mở danh bạ", "xem danh bạ", "mở sổ liên lạc")

    // Đặt "mở" (bare) ở CUỐI vì nó là từ khóa chung nhất, dài -> ngắn để khớp đúng cụm cụ thể trước
    private val OPEN_APP_PATTERNS = listOf("mở ứng dụng", "mở app", "mở")

    fun handle(context: Context, rawText: String): CommandResult {
        val text = rawText.trim().lowercase(Locale.forLanguageTag("vi-VN"))

        // 1. Nhạc
        matchAndExtract(text, PLAY_PATTERNS)?.let { query ->
            val ok = playMusic(context, query)
            return if (ok) {
                CommandResult(true, if (query.isBlank()) "Đang mở nhạc cho bạn" else "Đang tìm $query trên YouTube")
            } else {
                CommandResult(true, "Máy chưa cài ứng dụng nào để mở nhạc/YouTube")
            }
        }
        if (PAUSE_PATTERNS.any { text.contains(it) }) {
            sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_PAUSE)
            return CommandResult(true, "Đã tạm dừng nhạc")
        }
        if (RESUME_PATTERNS.any { text.contains(it) }) {
            sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_PLAY)
            return CommandResult(true, "Tiếp tục phát nhạc")
        }
        if (NEXT_PATTERNS.any { text.contains(it) }) {
            sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_NEXT)
            return CommandResult(true, "Chuyển sang bài tiếp theo")
        }
        if (PREV_PATTERNS.any { text.contains(it) }) {
            sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            return CommandResult(true, "Quay lại bài trước")
        }

        // 2. Đèn pin
        if (FLASH_ON_PATTERNS.any { text.contains(it) }) {
            val ok = FlashlightController.turnOn(context)
            return CommandResult(true, if (ok) "Đã bật đèn pin" else "Máy này không hỗ trợ đèn pin")
        }
        if (FLASH_OFF_PATTERNS.any { text.contains(it) }) {
            val ok = FlashlightController.turnOff(context)
            return CommandResult(true, if (ok) "Đã tắt đèn pin" else "Không tắt được đèn pin")
        }

        // 2b. Mở camera để chào hỏi / nhận diện khuôn mặt
        if (CAMERA_PATTERNS.any { text.contains(it) }) {
            return CommandResult(true, "Đang mở camera để nhìn bạn nè", CommandAction.OPEN_CAMERA)
        }

        // 2c. Mở thẳng trình quay số / danh bạ (dùng khi không rõ tên người muốn gọi)
        if (OPEN_DIALER_PATTERNS.any { text.contains(it) }) {
            PhoneController.openDialer(context)
            return CommandResult(true, "Đang mở trình quay số")
        }
        if (OPEN_CONTACTS_PATTERNS.any { text.contains(it) }) {
            PhoneController.openContacts(context)
            return CommandResult(true, "Đang mở danh bạ")
        }

        // 3. Gọi điện — theo tên trong danh bạ. Nhận diện LINH HOẠT: bất kỳ câu nào
        // có dạng "gọi ... cho <tên>" (vd "gọi cho mẹ", "gọi điện thoại cho ba",
        // "làm ơn gọi video cho em"...) đều bắt được, không cần đúng y nguyên mẫu câu.
        tryExtractCallName(text)?.let { name ->
            return handlePhoneCallByName(context, name)
        }

        // 4. Gọi điện — theo số đọc trực tiếp
        matchAndExtract(text, CALL_NUMBER_PATTERNS)?.let { spoken ->
            val digits = spoken.filter { it.isDigit() }
            return if (digits.length >= 5) {
                PhoneController.call(context, digits)
                CommandResult(true, "Đang gọi số $digits")
            } else {
                CommandResult(true, "Bạn nói lại số điện thoại giúp mình nhé")
            }
        }

        // 5. Mở app (kiểm tra cuối cùng vì "mở" là từ khóa rất chung)
        matchAndExtract(text, OPEN_APP_PATTERNS)?.let { appName ->
            if (appName.isBlank()) return CommandResult(false)
            val ok = AppLauncher.openApp(context, appName)
            return CommandResult(true, if (ok) "Đang mở $appName" else "Không tìm thấy ứng dụng $appName trên máy")
        }

        return CommandResult(false)
    }

    private fun handlePhoneCallByName(context: Context, name: String): CommandResult {
        if (name.isBlank()) return CommandResult(true, "Bạn muốn gọi cho ai?")
        if (!PhoneController.hasContactsPermission(context)) {
            return CommandResult(true, "Chưa có quyền đọc danh bạ. Vào Cài đặt máy để cấp quyền cho app nhé")
        }
        val number = PhoneController.findContactNumber(context, name)
        return if (number != null) {
            PhoneController.call(context, number)
            CommandResult(true, "Đang gọi cho $name")
        } else {
            CommandResult(true, "Không tìm thấy $name trong danh bạ")
        }
    }

    /**
     * Nhận diện linh hoạt câu "gọi điện": tìm chữ "gọi" rồi tìm chữ "cho" xuất
     * hiện sau đó, lấy phần còn lại sau "cho" làm tên người cần gọi. Khớp được
     * mọi biến thể như "gọi cho X", "gọi điện cho X", "gọi điện thoại cho X",
     * "gọi video cho X"... thay vì phải liệt kê từng mẫu câu cứng.
     */
    private fun tryExtractCallName(text: String): String? {
        val goiIdx = text.indexOf("gọi")
        if (goiIdx < 0) return null
        val choIdx = text.indexOf("cho", goiIdx + 3)
        if (choIdx < 0) return null

        // Phần giữa "gọi" và "cho" phải ngắn (ví dụ "điện thoại", "video") để
        // tránh bắt nhầm câu không liên quan tới gọi điện.
        val between = text.substring(goiIdx + 3, choIdx).trim()
        if (between.split(" ").filter { it.isNotBlank() }.size > 3) return null

        return text.substring(choIdx + 3).trim()
    }

    /** Nếu câu nói khớp 1 pattern, trả về phần còn lại sau pattern đó (tên bài hát/app/người, có thể rỗng). */
    private fun matchAndExtract(text: String, patterns: List<String>): String? {
        for (p in patterns) {
            val idx = text.indexOf(p)
            if (idx >= 0) {
                val after = text.substring(idx + p.length).trim()
                return after.removePrefix("bài hát").removePrefix("bài").trim()
            }
        }
        return null
    }

    /**
     * Nếu KHÔNG có tên bài cụ thể ("mở nhạc" trống) -> nhờ hệ thống mở app nhạc
     * mặc định phát ngẫu nhiên (hoạt động tốt với các app nhạc thật như Spotify,
     * Zing MP3...).
     * Nếu CÓ tên bài cụ thể -> mở thẳng trang tìm kiếm YouTube bằng link web
     * chuẩn, ổn định hơn nhiều so với Intent PLAY_FROM_SEARCH (intent đó khiến
     * YouTube bị treo/trắng màn hình trên một số máy).
     */
    private fun playMusic(context: Context, query: String): Boolean {
        return try {
            val intent = if (query.isBlank()) {
                Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                val searchUrl = "https://www.youtube.com/results?search_query=" + Uri.encode(query)
                Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        }
    }

    private fun sendMediaKey(context: Context, keyCode: Int) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }
}
