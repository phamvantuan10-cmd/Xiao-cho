package com.xiaotro.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.core.content.ContextCompat

data class SimpleLocation(val latitude: Double, val longitude: Double)

/**
 * Lấy vị trí gần nhất đã biết của máy (không yêu cầu dò GPS mất thời gian) —
 * đủ dùng cho việc tra thời tiết mà không cần độ chính xác cao.
 */
object LocationHelper {
    fun hasLocationPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
    }

    fun getLastKnownLocation(context: Context): SimpleLocation? {
        if (!hasLocationPermission(context)) return null
        return try {
            val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            for (provider in providers) {
                try {
                    val location = locationManager.getLastKnownLocation(provider)
                    if (location != null) {
                        return SimpleLocation(location.latitude, location.longitude)
                    }
                } catch (e: SecurityException) {
                    // bỏ qua, thử provider tiếp theo
                } catch (e: IllegalArgumentException) {
                    // provider không tồn tại trên máy này, thử provider tiếp theo
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }
}
