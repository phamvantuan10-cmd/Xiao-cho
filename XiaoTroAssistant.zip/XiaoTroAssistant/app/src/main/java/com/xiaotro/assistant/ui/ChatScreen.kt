package com.xiaotro.assistant.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xiaotro.assistant.AppPreferences
import com.xiaotro.assistant.AssistantState
import com.xiaotro.assistant.AssistantUiState
import com.xiaotro.assistant.ChatMessage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    uiState: AssistantUiState,
    onMicClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onCameraClick: () -> Unit
) {
    val context = LocalContext.current
    val voiceOnlyMode = AppPreferences.voiceOnlyMode(context)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Xiao Trợ Lý") },
                actions = {
                    IconButton(onClick = onCameraClick) {
                        Icon(Icons.Default.CameraAlt, contentDescription = "Mở camera")
                    }
                    IconButton(onClick = onSettingsClick) {
                        Icon(Icons.Default.Settings, contentDescription = "Cài đặt")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onMicClick) {
                val icon = when {
                    uiState.state == AssistantState.SPEAKING -> "⏹️" // bấm để ngắt lời
                    uiState.continuousActive -> "⏹️" // đang nghe liên tục, bấm để dừng
                    else -> "🎤"
                }
                Text(icon)
            }
        }
    ) { padding ->
        if (voiceOnlyMode) {
            VoiceOnlyScreen(uiState = uiState, modifier = Modifier.padding(padding))
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(12.dp)
            ) {
                StatusBanner(uiState)

                Spacer(Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(uiState.messages) { message ->
                        MessageBubble(message)
                    }
                }
            }
        }
    }
}

/**
 * Giao diện tối giản cho "chế độ chỉ giọng nói": không hiện khung chat,
 * chỉ 1 icon lớn + trạng thái hiện tại — giao tiếp thuần bằng lời nói.
 */
@Composable
private fun VoiceOnlyScreen(uiState: AssistantUiState, modifier: Modifier = Modifier) {
    val (icon, label) = when (uiState.state) {
        AssistantState.IDLE -> if (uiState.continuousActive) {
            "👂" to "Đang chờ bạn nói (nghe liên tục)..."
        } else {
            "🎤" to "Sẵn sàng — bấm mic hoặc nói từ khóa đánh thức"
        }
        AssistantState.LISTENING -> "🎙️" to "Đang nghe..."
        AssistantState.THINKING -> "🤔" to "Đang suy nghĩ..."
        AssistantState.SPEAKING -> "🔊" to "Đang trả lời..."
        AssistantState.ERROR -> "⚠️" to (uiState.errorText ?: "Có lỗi xảy ra")
    }

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(icon, fontSize = 96.sp)
        Spacer(Modifier.height(24.dp))
        Text(
            label,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(horizontal = 32.dp)
        )
    }
}

@Composable
private fun StatusBanner(uiState: AssistantUiState) {
    val label = when (uiState.state) {
        AssistantState.IDLE -> "Sẵn sàng — nói \"Hey Trợ Lý\" hoặc bấm nút mic"
        AssistantState.LISTENING -> "Đang nghe..."
        AssistantState.THINKING -> "Đang suy nghĩ..."
        AssistantState.SPEAKING -> "Đang trả lời..."
        AssistantState.ERROR -> uiState.errorText ?: "Có lỗi xảy ra"
    }
    Text(label, style = MaterialTheme.typography.bodyMedium)
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val alignment = if (message.isUser) Alignment.CenterEnd else Alignment.CenterStart
    val bubbleColor = if (message.isUser) Color(0xFFDCF0FF) else Color(0xFFF0F0F0)

    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = alignment) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = message.text,
                modifier = Modifier.padding(10.dp)
            )
        }
    }
}
