package com.xiaotro.assistant

import android.content.Context
import android.content.Intent
import java.text.Normalizer

/**
 * Tìm app đã cài theo tên đọc gần đúng (không phân biệt hoa/thường, có/không dấu)
 * rồi mở lên. Dùng Intent chuẩn ACTION_MAIN/CATEGORY_LAUNCHER để liệt kê app —
 * đây là 1 trong các trường hợp được Android miễn trừ khỏi giới hạn package
 * visibility (Android 11+), nên không cần khai báo thêm quyền gì.
 */
object AppLauncher {

    fun openApp(context: Context, spokenName: String): Boolean {
        val target = normalize(spokenName)
        if (target.isBlank()) return false

        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, 0)

        // Ưu tiên khớp chính xác nhất trước (tên app trùng đúng cụm từ được nói)
        val match = apps.firstOrNull { info ->
            normalize(info.loadLabel(pm).toString()) == target
        } ?: apps.firstOrNull { info ->
            val label = normalize(info.loadLabel(pm).toString())
            label.contains(target) || target.contains(label)
        } ?: return false

        val packageName = match.activityInfo.packageName
        val intent = pm.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    private fun normalize(text: String): String {
        val lower = text.lowercase().replace('đ', 'd')
        val noAccents = Normalizer.normalize(lower, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return noAccents.trim()
    }
}
