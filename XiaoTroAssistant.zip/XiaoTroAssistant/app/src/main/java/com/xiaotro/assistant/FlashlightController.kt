package com.xiaotro.assistant

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager

/**
 * Bật/tắt đèn pin qua Camera2 API. Lưu ý: setTorchMode() KHÔNG cần quyền
 * CAMERA (chỉ điều khiển đèn flash, không mở camera để chụp/quay).
 */
object FlashlightController {
    private var isOn = false

    fun turnOn(context: Context): Boolean = setTorch(context, true)
    fun turnOff(context: Context): Boolean = setTorch(context, false)

    private fun setTorch(context: Context, on: Boolean): Boolean {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false

            cameraManager.setTorchMode(cameraId, on)
            isOn = on
            true
        } catch (e: Exception) {
            false
        }
    }
}
