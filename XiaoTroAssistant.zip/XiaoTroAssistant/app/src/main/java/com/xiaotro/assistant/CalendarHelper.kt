package com.xiaotro.assistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.provider.CalendarContract

/**
 * Mở màn hình "Thêm sự kiện mới" của app Lịch có sẵn trên máy, điền sẵn tiêu đề
 * theo lời bạn nói. Người dùng tự chọn ngày/giờ và bấm Lưu — cách này đơn giản,
 * đáng tin cậy, không cần app tự "đoán" ngày giờ từ câu nói (dễ đoán sai).
 */
object CalendarHelper {
    fun openNewEvent(context: Context, title: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_INSERT).apply {
                data = CalendarContract.Events.CONTENT_URI
                putExtra(CalendarContract.Events.TITLE, title.ifBlank { "Sự kiện mới" })
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        }
    }
}
