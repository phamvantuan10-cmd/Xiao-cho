package com.xiaotro.assistant

/**
 * Các hằng số KHÔNG bí mật của app. API key thật (Gemini, Picovoice, Cloud TTS)
 * giờ được nhập trực tiếp trong app qua màn hình Cài đặt (Settings) và lưu trong
 * AppPreferences — xem AppPreferences.kt.
 */
object Config {
    const val GEMINI_MODEL: String = "gemini-3.6-flash"

    // Tên file .ppn đặt trong assets/. Nếu chưa có file từ khóa tiếng Việt riêng,
    // xem README để tạm dùng keyword có sẵn của Porcupine trong lúc chờ tạo.
    const val WAKE_WORD_ASSET_FILE: String = "wakeword_vi_android.ppn"

    const val SYSTEM_PROMPT: String =
        "Bạn là một trợ lý ảo tiếng Việt thân thiện, tên là Xiao. " +
            "Trả lời ngắn gọn, tự nhiên như đang nói chuyện bằng giọng nói, " +
            "tránh dùng markdown hay danh sách dài vì câu trả lời sẽ được đọc to lên."
}
