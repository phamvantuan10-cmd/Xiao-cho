package com.xiaotro.assistant

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.sqrt

/**
 * Nhận diện DANH TÍNH khuôn mặt (khác với phát hiện khuôn mặt/biểu cảm của ML Kit
 * ở FaceMoodAnalyzer). Dùng model MobileFaceNet (.tflite) để tạo "embedding" —
 * một vector số đại diện riêng cho từng khuôn mặt, so khớp 2 khuôn mặt bằng
 * cosine similarity.
 *
 * TÍNH NĂNG NÀY LÀ TÙY CHỌN. Nếu bạn CHƯA bỏ file mobilefacenet.tflite vào
 * assets/, `isAvailable` sẽ là false và app tự bỏ qua bước nhận diện danh tính
 * (vẫn phân tích biểu cảm bình thường). Xem README để biết cách lấy model.
 *
 * Lưu ý độ chính xác: đây là bản demo đơn giản (không crop/align khuôn mặt kỹ),
 * không nên dùng để bảo vệ dữ liệu nhạy cảm hay thay thế khóa màn hình thật.
 */
class FaceEmbedder(context: Context) {

    private val interpreter: Interpreter? = try {
        Interpreter(loadModelFile(context, "mobilefacenet.tflite"))
    } catch (e: Exception) {
        null // chưa có file model -> tắt tính năng nhận diện danh tính
    }

    val isAvailable: Boolean get() = interpreter != null

    /** Trả về vector embedding 192 chiều đại diện cho khuôn mặt, hoặc null nếu lỗi/chưa có model. */
    fun embed(faceBitmap: Bitmap): FloatArray? {
        val model = interpreter ?: return null
        return try {
            val input = preprocess(faceBitmap)
            val output = Array(1) { FloatArray(EMBEDDING_SIZE) }
            model.run(input, output)
            output[0]
        } catch (e: Exception) {
            null
        }
    }

    private fun preprocess(bitmap: Bitmap): Array<Array<Array<FloatArray>>> {
        val resized = Bitmap.createScaledBitmap(bitmap, INPUT_SIZE, INPUT_SIZE, true)
        val input = Array(1) { Array(INPUT_SIZE) { Array(INPUT_SIZE) { FloatArray(3) } } }
        for (y in 0 until INPUT_SIZE) {
            for (x in 0 until INPUT_SIZE) {
                val pixel = resized.getPixel(x, y)
                input[0][y][x][0] = (((pixel shr 16) and 0xFF) - 127.5f) / 128f
                input[0][y][x][1] = (((pixel shr 8) and 0xFF) - 127.5f) / 128f
                input[0][y][x][2] = ((pixel and 0xFF) - 127.5f) / 128f
            }
        }
        return input
    }

    private fun loadModelFile(context: Context, assetName: String): MappedByteBuffer {
        val fd = context.assets.openFd(assetName)
        val inputStream = FileInputStream(fd.fileDescriptor)
        return inputStream.channel.map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
    }

    companion object {
        private const val INPUT_SIZE = 112
        private const val EMBEDDING_SIZE = 192

        /** Ngưỡng gợi ý: > 0.6 thường coi là cùng một người, có thể cần chỉnh theo thực tế. */
        const val MATCH_THRESHOLD = 0.6f

        fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
            if (a.size != b.size) return -1f
            var dot = 0f
            var normA = 0f
            var normB = 0f
            for (i in a.indices) {
                dot += a[i] * b[i]
                normA += a[i] * a[i]
                normB += b[i] * b[i]
            }
            if (normA == 0f || normB == 0f) return -1f
            return dot / (sqrt(normA) * sqrt(normB))
        }
    }
}
