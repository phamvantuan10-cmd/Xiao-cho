package com.xiaotro.assistant.service

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Cầu nối đơn giản: khi WakeWordService (chạy nền, luôn nghe) phát hiện
 * từ khóa đánh thức, nó phát 1 sự kiện qua đây. AssistantViewModel lắng nghe
 * sự kiện này để bắt đầu quy trình ghi âm câu hỏi -> gọi AI -> đọc trả lời.
 */
object AssistantEvents {
    private val _wakeWordDetected = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val wakeWordDetected: SharedFlow<Unit> = _wakeWordDetected.asSharedFlow()

    fun onWakeWordDetected() {
        _wakeWordDetected.tryEmit(Unit)
    }
}
