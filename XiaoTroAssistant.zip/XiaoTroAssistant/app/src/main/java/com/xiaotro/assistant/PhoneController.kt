package com.xiaotro.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import java.text.Normalizer

/**
 * Tìm số điện thoại theo tên trong danh bạ (cần quyền READ_CONTACTS) và thực hiện
 * cuộc gọi. Nếu có quyền CALL_PHONE thì gọi thẳng; nếu không, mở màn hình quay số
 * sẵn số điện thoại để người dùng tự bấm gọi (an toàn hơn, không cần quyền nhạy cảm).
 */
object PhoneController {

    fun hasContactsPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    fun findContactNumber(context: Context, spokenName: String): String? {
        if (!hasContactsPermission(context)) return null
        val target = normalize(spokenName)
        if (target.isBlank()) return null

        val resolver = context.contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        ) ?: return null

        cursor.use {
            val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                val name = it.getString(nameIdx) ?: continue
                if (normalize(name).contains(target)) {
                    return it.getString(numberIdx)
                }
            }
        }
        return null
    }

    fun call(context: Context, phoneNumber: String) {
        val hasCallPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED
        val action = if (hasCallPermission) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val intent = Intent(action, Uri.parse("tel:$phoneNumber")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /** Mở màn hình bàn phím quay số (trống, chưa điền số) — dùng khi chưa rõ gọi cho ai/số nào. */
    fun openDialer(context: Context) {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /** Mở app Danh bạ để người dùng tự chọn liên hệ. */
    fun openContacts(context: Context) {
        val intent = Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    private fun normalize(text: String): String {
        val lower = text.lowercase().replace('đ', 'd')
        val noAccents = Normalizer.normalize(lower, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return noAccents.trim()
    }
}
