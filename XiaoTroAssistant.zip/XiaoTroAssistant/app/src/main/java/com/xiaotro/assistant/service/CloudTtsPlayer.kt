package com.xiaotro.assistant.service

import android.media.MediaPlayer
import java.io.File

/**
 * Phát file audio từ Cloud TTS. Tách riêng thành object đơn giản để
 * AssistantViewModel có thể gọi stop() bất cứ lúc nào — đây là cơ chế
 * "ngắt lời" (barge-in): khi người dùng bấm mic hoặc nói từ khóa đánh thức
 * trong lúc trợ lý đang nói, playback bị dừng ngay lập tức.
 */
object CloudTtsPlayer {
    private var mediaPlayer: MediaPlayer? = null

    fun play(file: File, onDone: () -> Unit, onError: (String) -> Unit) {
        stop()
        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener {
                    release()
                    mediaPlayer = null
                    onDone()
                }
                setOnErrorListener { _, what, extra ->
                    release()
                    mediaPlayer = null
                    onError("MediaPlayer lỗi ($what, $extra)")
                    true
                }
                prepare()
                start()
            }
        } catch (e: Exception) {
            onError(e.message ?: "Không phát được audio")
        }
    }

    /** Dừng ngay lập tức, dùng khi người dùng ngắt lời trợ lý. */
    fun stop() {
        mediaPlayer?.let {
            try {
                if (it.isPlaying) it.stop()
            } catch (_: Exception) {
                // đã bị release hoặc chưa prepare xong, bỏ qua
            }
            it.release()
        }
        mediaPlayer = null
    }

    fun isPlaying(): Boolean = mediaPlayer?.isPlaying == true
}
