package com.xiaotro.assistant

import android.content.Context

/**
 * "Trí nhớ dài hạn" của Xiao — khác với lịch sử hội thoại trong GeminiRepository
 * (mất khi tắt app), những gì lưu ở đây tồn tại VĨNH VIỄN qua các lần mở app
 * khác nhau (chỉ mất khi gỡ cài app). Đây là cách đơn giản, đáng tin cậy để
 * Xiao "nhớ" về bạn — người dùng chủ động dặn điều gì cần nhớ, thay vì để AI
 * tự ý ghi nhớ mọi thứ (dễ gây lưu thông tin không mong muốn).
 */
object MemoryStore {
    private const val PREFS_NAME = "xiaotro_memory"
    private const val KEY_MEMORIES = "memories"
    private const val SEPARATOR = "\u0001" // ký tự phân cách hiếm khi xuất hiện trong câu nói thường

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getAll(context: Context): List<String> {
        val raw = prefs(context).getString(KEY_MEMORIES, "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split(SEPARATOR).filter { it.isNotBlank() }
    }

    fun add(context: Context, fact: String) {
        val current = getAll(context).toMutableList()
        current.add(fact.trim())
        // Giới hạn 100 mục gần nhất để tránh phình to vô hạn, làm chậm mỗi lần gọi AI
        val trimmed = if (current.size > 100) current.takeLast(100) else current
        prefs(context).edit().putString(KEY_MEMORIES, trimmed.joinToString(SEPARATOR)).apply()
    }

    fun clear(context: Context) {
        prefs(context).edit().remove(KEY_MEMORIES).apply()
    }

    /** Ghép thành đoạn văn ngắn để chèn vào system prompt gửi cho Gemini. */
    fun asPromptContext(context: Context): String {
        val memories = getAll(context)
        if (memories.isEmpty()) return ""
        return "Những điều bạn đã được dặn ghi nhớ về người dùng này ở các lần trò chuyện trước:\n" +
            memories.joinToString("\n") { "- $it" }
    }
}
