package com.xiaotro.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.xiaotro.assistant.service.WakeWordService
import com.xiaotro.assistant.ui.CameraGreetingScreen
import com.xiaotro.assistant.ui.ChatScreen
import com.xiaotro.assistant.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    private val viewModel: AssistantViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.RECORD_AUDIO] == true) {
            startWakeWordService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestNeededPermissions()

        setContent {
            var showSettings by remember { mutableStateOf(false) }
            var showCamera by remember { mutableStateOf(false) }
            var lastHandledCameraRequestId by remember { mutableStateOf(0) }
            val uiState by viewModel.uiState.collectAsState()

            // Lệnh giọng nói "mở camera" tăng cameraRequestId -> tự mở màn hình camera
            LaunchedEffect(uiState.cameraRequestId) {
                if (uiState.cameraRequestId != lastHandledCameraRequestId) {
                    lastHandledCameraRequestId = uiState.cameraRequestId
                    showCamera = true
                }
            }

            when {
                showCamera -> {
                    CameraGreetingScreen(
                        onClose = { showCamera = false },
                        onGreet = { mood, bitmap ->
                            // KHÔNG đóng camera ở đây nữa — camera ở nguyên màn hình để tiếp tục
                            // giao tiếp, chỉ tự đóng khi không thấy ai trong khung hình 5 giây
                            // (xử lý ngay trong CameraGreetingScreen) hoặc khi bấm nút "Đóng".
                            viewModel.handleCameraGreeting(mood, bitmap)
                        },
                        onEnrollRequested = { bitmap ->
                            viewModel.enrollOwnerFace(bitmap) { result, detail ->
                                val message = when (result) {
                                    EnrollResult.SUCCESS -> "Đã ghi nhớ khuôn mặt của bạn"
                                    EnrollResult.MODEL_NOT_LOADED ->
                                        "LỖI MODEL: ${detail ?: "không rõ nguyên nhân"}"
                                    EnrollResult.NO_FACE_DETECTED ->
                                        "LỖI: không tìm thấy khuôn mặt trong ảnh (thử đứng gần, đủ sáng, nhìn thẳng camera)"
                                    EnrollResult.EMBEDDING_FAILED ->
                                        "LỖI: tìm thấy mặt nhưng xử lý nhận diện bị lỗi"
                                }
                                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                            }
                        }
                    )
                }
                showSettings -> {
                    SettingsScreen(
                        onBack = { showSettings = false },
                        onSaved = {
                            restartWakeWordService()
                            showSettings = false
                        }
                    )
                }
                else -> {
                    ChatScreen(
                        uiState = uiState,
                        onMicClick = { viewModel.onPrimaryButtonClick() },
                        onSettingsClick = { showSettings = true },
                        onCameraClick = { showCamera = true }
                    )
                }
            }
        }
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val notGranted = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (notGranted.isEmpty()) {
            startWakeWordService()
        } else {
            permissionLauncher.launch(notGranted.toTypedArray())
        }
    }

    private fun startWakeWordService() {
        val intent = Intent(this, WakeWordService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    /** Gọi sau khi người dùng lưu key mới trong Cài đặt, để wake-word nạp lại key/từ khóa. */
    private fun restartWakeWordService() {
        val intent = Intent(this, WakeWordService::class.java).apply {
            action = WakeWordService.ACTION_RESTART
        }
        ContextCompat.startForegroundService(this, intent)
    }
}
