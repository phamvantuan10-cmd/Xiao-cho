package com.xiaotro.assistant

import android.content.Context

/**
 * Lưu API key và tùy chọn ngay trên máy (SharedPreferences), để người dùng
 * nhập key qua màn hình Cài đặt trong app thay vì phải sửa code.
 *
 * Lưu ý bảo mật: SharedPreferences thường không mã hóa, đủ dùng cho app cá nhân/demo.
 * Nếu làm app phát hành thật, nên dùng EncryptedSharedPreferences (Jetpack Security).
 */
object AppPreferences {
    private const val PREFS_NAME = "xiaotro_settings"

    private const val KEY_GEMINI = "gemini_api_key"
    private const val KEY_PICOVOICE = "picovoice_access_key"
    private const val KEY_CLOUD_TTS_KEY = "cloud_tts_api_key"
    private const val KEY_USE_CLOUD_TTS = "use_cloud_tts"
    private const val KEY_CLOUD_TTS_VOICE = "cloud_tts_voice"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun geminiKey(context: Context): String = prefs(context).getString(KEY_GEMINI, "") ?: ""
    fun setGeminiKey(context: Context, value: String) {
        prefs(context).edit().putString(KEY_GEMINI, value.trim()).apply()
    }

    fun picovoiceKey(context: Context): String = prefs(context).getString(KEY_PICOVOICE, "") ?: ""
    fun setPicovoiceKey(context: Context, value: String) {
        prefs(context).edit().putString(KEY_PICOVOICE, value.trim()).apply()
    }

    fun cloudTtsKey(context: Context): String = prefs(context).getString(KEY_CLOUD_TTS_KEY, "") ?: ""
    fun setCloudTtsKey(context: Context, value: String) {
        prefs(context).edit().putString(KEY_CLOUD_TTS_KEY, value.trim()).apply()
    }

    fun useCloudTts(context: Context): Boolean = prefs(context).getBoolean(KEY_USE_CLOUD_TTS, false)
    fun setUseCloudTts(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_USE_CLOUD_TTS, value).apply()
    }

    // Giọng WaveNet tiếng Việt mặc định của Google Cloud TTS
    fun cloudTtsVoice(context: Context): String =
        prefs(context).getString(KEY_CLOUD_TTS_VOICE, "vi-VN-Wavenet-A") ?: "vi-VN-Wavenet-A"
    fun setCloudTtsVoice(context: Context, value: String) {
        prefs(context).edit().putString(KEY_CLOUD_TTS_VOICE, value.trim()).apply()
    }

    fun hasMinimumSetup(context: Context): Boolean =
        geminiKey(context).isNotBlank() && picovoiceKey(context).isNotBlank()

    // --- Dữ liệu khuôn mặt chủ nhân (embedding do FaceEmbedder tạo ra) ---
    private const val KEY_OWNER_FACE = "owner_face_embedding"

    fun ownerFaceEmbedding(context: Context): FloatArray? {
        val raw = prefs(context).getString(KEY_OWNER_FACE, null) ?: return null
        return try {
            raw.split(",").map { it.toFloat() }.toFloatArray()
        } catch (e: Exception) {
            null
        }
    }

    fun setOwnerFaceEmbedding(context: Context, embedding: FloatArray) {
        prefs(context).edit().putString(KEY_OWNER_FACE, embedding.joinToString(",")).apply()
    }

    fun hasOwnerFace(context: Context): Boolean = prefs(context).contains(KEY_OWNER_FACE)

    fun clearOwnerFace(context: Context) {
        prefs(context).edit().remove(KEY_OWNER_FACE).apply()
    }
}
