package com.xiaotro.assistant.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.xiaotro.assistant.FaceMoodAnalyzer

/**
 * Màn hình camera: hiện preview trực tiếp, tự phát hiện khuôn mặt + biểu cảm
 * bằng ML Kit. Khi thấy 1 khuôn mặt ổn định trong ~1.5 giây, tự động chụp 1
 * ảnh và gọi onGreet() để ViewModel phân tích danh tính + tạo lời chào tự nhiên.
 */
@OptIn(ExperimentalGetImage::class)
@Composable
fun CameraGreetingScreen(
    onClose: () -> Unit,
    onGreet: (moodLabel: String, faceBitmap: Bitmap?) -> Unit,
    onEnrollRequested: (faceBitmap: Bitmap) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val hasCameraPermission = ContextCompat.checkSelfPermission(
        context, Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    if (!hasCameraPermission) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Chưa có quyền Camera. Vào Cài đặt máy để cấp quyền nhé.")
                Spacer(Modifier.height(12.dp))
                Button(onClick = onClose) { Text("Đóng") }
            }
        }
        return
    }

    var moodLabel by remember { mutableStateOf("Đang tìm khuôn mặt...") }
    var autoGreeted by remember { mutableStateOf(false) }
    val imageCapture = remember { ImageCapture.Builder().build() }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val previewView = PreviewView(ctx)
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)

                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()

                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                    val analysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()

                    val detector = FaceDetection.getClient(
                        FaceDetectorOptions.Builder()
                            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                            .build()
                    )

                    var stableSinceMs = 0L

                    analysis.setAnalyzer(ContextCompat.getMainExecutor(ctx)) { imageProxy ->
                        val mediaImage = imageProxy.image
                        if (mediaImage == null) {
                            imageProxy.close()
                        } else {
                            val inputImage = InputImage.fromMediaImage(
                                mediaImage, imageProxy.imageInfo.rotationDegrees
                            )
                            detector.process(inputImage)
                                .addOnSuccessListener { faces ->
                                    if (faces.isNotEmpty()) {
                                        moodLabel = FaceMoodAnalyzer.classifyMood(faces[0])
                                        if (stableSinceMs == 0L) stableSinceMs = System.currentTimeMillis()

                                        if (!autoGreeted && System.currentTimeMillis() - stableSinceMs > 1500) {
                                            autoGreeted = true
                                            val currentMood = moodLabel
                                            capturePhoto(imageCapture, ctx) { bitmap ->
                                                onGreet(currentMood, bitmap)
                                            }
                                        }
                                    } else {
                                        stableSinceMs = 0L
                                        moodLabel = "Đang tìm khuôn mặt..."
                                    }
                                }
                                .addOnCompleteListener { imageProxy.close() }
                        }
                    }

                    try {
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            CameraSelector.DEFAULT_FRONT_CAMERA,
                            preview,
                            analysis,
                            imageCapture
                        )
                    } catch (e: Exception) {
                        moodLabel = "Không mở được camera: ${e.message}"
                    }
                }, ContextCompat.getMainExecutor(ctx))

                previewView
            }
        )

        // Overlay: nhãn biểu cảm
        Surface(
            color = Color.Black.copy(alpha = 0.55f),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 24.dp)
        ) {
            Text(
                text = moodLabel,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        // Overlay: nút điều khiển
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.4f))
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = onClose) { Text("Đóng") }
            Button(onClick = {
                capturePhoto(imageCapture, context) { bitmap ->
                    if (bitmap != null) onEnrollRequested(bitmap)
                }
            }) { Text("Ghi nhớ đây là tôi") }
        }
    }
}

private fun capturePhoto(
    imageCapture: ImageCapture,
    context: android.content.Context,
    onResult: (Bitmap?) -> Unit
) {
    imageCapture.takePicture(
        ContextCompat.getMainExecutor(context),
        object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                // QUAN TRỌNG: đọc chiều xoay thật của ảnh từ thông tin EXIF ngay trong
                // file JPEG — cách này đáng tin cậy hơn image.imageInfo.rotationDegrees
                // vì không phụ thuộc vào cách từng hãng máy xử lý camera. Nếu không xoay
                // đúng chiều, khuôn mặt bị nghiêng/ngang khiến ML Kit không nhận ra được.
                val bitmap = try {
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining())
                    buffer.get(bytes)

                    val exif = ExifInterface(java.io.ByteArrayInputStream(bytes))
                    val orientation = exif.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )
                    val degreesFromExif = when (orientation) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                    // Nếu EXIF không có thông tin xoay (NORMAL) nhưng CameraX báo có xoay,
                    // vẫn ưu tiên dùng giá trị từ CameraX làm phương án dự phòng.
                    val degrees = if (degreesFromExif != 0f) degreesFromExif else image.imageInfo.rotationDegrees.toFloat()

                    val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (decoded != null && degrees != 0f) {
                        val matrix = Matrix().apply { postRotate(degrees) }
                        Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
                    } else {
                        decoded
                    }
                } catch (e: Exception) {
                    null
                }
                image.close()
                onResult(bitmap)
            }

            override fun onError(exception: ImageCaptureException) {
                onResult(null)
            }
        }
    )
}
