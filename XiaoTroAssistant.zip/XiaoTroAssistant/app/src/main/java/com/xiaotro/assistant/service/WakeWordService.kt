package com.xiaotro.assistant.service

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.xiaotro.assistant.AppPreferences
import com.xiaotro.assistant.R

/**
 * Service chạy nền LIÊN TỤC để nghe từ khóa đánh thức (giống Xiaozhi "always listening").
 * Dùng Porcupine vì nó cực nhẹ, chạy on-device, không tốn pin/băng thông như việc
 * liên tục gửi audio lên server để nhận diện.
 *
 * Khi phát hiện từ khóa -> phát sự kiện qua AssistantEvents -> UI/ViewModel xử lý tiếp
 * (ghi âm câu hỏi thật, gửi STT, gọi Gemini, đọc trả lời bằng TTS).
 */
class WakeWordService : Service() {

    private var porcupineManager: PorcupineManager? = null

    companion object {
        private const val TAG = "WakeWordService"
        private const val CHANNEL_ID = "wake_word_channel"
        private const val NOTIFICATION_ID = 1001
        const val ACTION_RESTART = "com.xiaotro.assistant.action.RESTART_WAKE_WORD"
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
        startPorcupine()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_RESTART) {
            restartPorcupine()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startPorcupine() {
        val accessKey = AppPreferences.picovoiceKey(applicationContext)
        if (accessKey.isBlank()) {
            Log.w(TAG, "Chưa có Picovoice access key — vào Cài đặt trong app để thêm. Wake word tạm tắt.")
            return
        }

        try {
            val callback = PorcupineManagerCallback { _ ->
                Log.d(TAG, "Wake word detected!")
                AssistantEvents.onWakeWordDetected()
            }

            // Dùng từ khóa CÓ SẴN của Porcupine ("Computer") thay vì cần file .ppn tùy chỉnh
            // -> không cần tự tạo/tải model riêng, chạy được ngay sau khi có access key.
            // Muốn đổi từ khóa khác có sẵn: ALEXA, BUMBLEBEE, COMPUTER, GRASSHOPPER,
            // JARVIS, PICOVOICE, PORCUPINE, TERMINATOR (đều là từ tiếng Anh).
            porcupineManager = PorcupineManager.Builder()
                .setAccessKey(accessKey)
                .setKeyword(Porcupine.BuiltInKeyword.COMPUTER)
                .setSensitivity(0.6f)
                .build(applicationContext, callback)

            porcupineManager?.start()
        } catch (e: Exception) {
            Log.e(TAG, "Không khởi động được Porcupine: ${e.message}", e)
        }
    }

    /** Gọi lại hàm này sau khi người dùng lưu key/wake word mới trong Cài đặt. */
    private fun restartPorcupine() {
        porcupineManager?.stop()
        porcupineManager?.delete()
        porcupineManager = null
        startPorcupine()
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.wake_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.wake_notification_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        porcupineManager?.stop()
        porcupineManager?.delete()
        super.onDestroy()
    }
}
