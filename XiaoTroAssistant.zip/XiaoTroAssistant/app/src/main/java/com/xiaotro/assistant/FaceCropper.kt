package com.xiaotro.assistant

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.tasks.await

/**
 * Cắt riêng vùng khuôn mặt ra khỏi 1 tấm ảnh chụp trước khi đưa vào FaceEmbedder.
 *
 * QUAN TRỌNG: nếu đưa nguyên cả tấm ảnh (gồm tóc, vai, nền) vào model nhận diện
 * danh tính, kết quả so khớp giữa 2 lần chụp khác góc/tư thế sẽ rất kém chính
 * xác — đây chính là lý do "ghi nhớ thành công nhưng không nhận ra chủ nhân".
 * Cắt sát khuôn mặt giúp kết quả ổn định hơn nhiều.
 */
object FaceCropper {
    private val detector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .build()
        )
    }

    /** Trả về bitmap đã cắt sát khuôn mặt (có thêm viền đệm), hoặc null nếu không thấy mặt nào. */
    suspend fun cropToFace(bitmap: Bitmap): Bitmap? {
        // Thử lần lượt các góc xoay 0°, 90°, 180°, 270° — đảm bảo tìm ra mặt kể cả
        // khi thông tin xoay ảnh (EXIF/CameraX) không chính xác trên 1 số máy.
        for (degrees in intArrayOf(0, 90, 180, 270)) {
            val candidate = if (degrees == 0) bitmap else rotate(bitmap, degrees)
            val result = detectAndCrop(candidate)
            if (result != null) return result
        }
        return null
    }

    private fun rotate(bitmap: Bitmap, degrees: Int): Bitmap {
        val matrix = android.graphics.Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private suspend fun detectAndCrop(bitmap: Bitmap): Bitmap? {
        return try {
            val inputImage = InputImage.fromBitmap(bitmap, 0)
            val faces = detector.process(inputImage).await()
            val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() } ?: return null

            val box = face.boundingBox
            // Thêm viền đệm quanh khuôn mặt (giúp model nhận diện đủ ngữ cảnh, không cắt sát quá)
            val paddingX = (box.width() * 0.3f).toInt()
            val paddingY = (box.height() * 0.3f).toInt()
            val left = (box.left - paddingX).coerceAtLeast(0)
            val top = (box.top - paddingY).coerceAtLeast(0)
            val right = (box.right + paddingX).coerceAtMost(bitmap.width)
            val bottom = (box.bottom + paddingY).coerceAtMost(bitmap.height)

            if (right <= left || bottom <= top) return null
            Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
        } catch (e: Exception) {
            null
        }
    }
}
