package com.xiaotro.assistant.network

import android.content.Context
import com.xiaotro.assistant.AppPreferences
import com.xiaotro.assistant.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatTurn(val role: String, val text: String) // role = "user" hoặc "model"

/**
 * Gọi Gemini API (gemini-2.5-flash) qua REST, giữ lịch sử hội thoại để trả lời
 * có ngữ cảnh, giống cách Xiaozhi gốc gọi LLM trên cloud.
 * API key được đọc từ AppPreferences (nhập qua màn hình Cài đặt trong app).
 */
class GeminiRepository(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    private val history = mutableListOf<ChatTurn>()

    /** Chỉ giữ lại vài lượt hội thoại gần nhất — gửi ít dữ liệu hơn giúp Gemini xử lý nhanh hơn. */
    private fun trimHistory() {
        val maxTurns = 6 // 3 câu hỏi + 3 câu trả lời gần nhất
        if (history.size > maxTurns) {
            val removeCount = history.size - maxTurns
            repeat(removeCount) { history.removeAt(0) }
        }
    }

    suspend fun ask(userText: String): String = withContext(Dispatchers.IO) {
        val apiKey = AppPreferences.geminiKey(context)
        if (apiKey.isBlank()) {
            throw IllegalStateException("Chưa nhập Gemini API key. Vào Cài đặt để thêm key.")
        }

        history.add(ChatTurn("user", userText))
        trimHistory()

        val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
            "${Config.GEMINI_MODEL}:generateContent?key=$apiKey"

        val contents = JSONArray()
        for (turn in history) {
            val part = JSONObject().put("text", turn.text)
            val parts = JSONArray().put(part)
            contents.put(
                JSONObject()
                    .put("role", turn.role)
                    .put("parts", parts)
            )
        }

        val body = JSONObject().apply {
            put("contents", contents)
            put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", Config.SYSTEM_PROMPT))
                )
            )
            put(
                "generationConfig",
                JSONObject()
                    .put("maxOutputTokens", 150)
                    .put("thinkingConfig", JSONObject().put("thinkingLevel", "minimal"))
            )
        }

        val request = Request.Builder()
            .url(url)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw Exception("Gemini API lỗi ${response.code}: $bodyStr")
            }
            val json = JSONObject(bodyStr)
            val reply = json
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
                .trim()

            history.add(ChatTurn("model", reply))
            reply
        }
    }

    fun clearHistory() {
        history.clear()
    }
}
