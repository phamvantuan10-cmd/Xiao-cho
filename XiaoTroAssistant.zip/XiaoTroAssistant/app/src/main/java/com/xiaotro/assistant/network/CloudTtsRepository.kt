package com.xiaotro.assistant.network

import android.content.Context
import android.util.Base64
import com.xiaotro.assistant.AppPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Gọi Google Cloud Text-to-Speech (giọng WaveNet) để có giọng đọc tự nhiên hơn
 * nhiều so với TextToSpeech mặc định của Android. Cần API key riêng, lấy tại
 * Google Cloud Console (bật "Cloud Text-to-Speech API"), nhập trong Cài đặt app.
 *
 * Lưu ý: Google yêu cầu bật billing trên project (thêm thẻ) để dùng API này,
 * dù usage nằm trong free tier hàng tháng thì không bị tính phí.
 */
class CloudTtsRepository(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    /** Gọi API, lưu audio MP3 vào cache và trả về đường dẫn file để phát. */
    suspend fun synthesizeToFile(text: String): File = withContext(Dispatchers.IO) {
        val apiKey = AppPreferences.cloudTtsKey(context)
        if (apiKey.isBlank()) {
            throw IllegalStateException("Chưa nhập Cloud TTS API key trong Cài đặt.")
        }
        val voiceName = AppPreferences.cloudTtsVoice(context)
        // vi-VN-Wavenet-A là giọng nữ; đổi languageCode theo voiceName để đúng chuẩn Google.
        val languageCode = voiceName.substringBeforeLast('-').substringBeforeLast('-').let {
            // ví dụ "vi-VN-Wavenet-A" -> "vi-VN"
            val parts = voiceName.split("-")
            if (parts.size >= 2) "${parts[0]}-${parts[1]}" else "vi-VN"
        }

        val url = "https://texttospeech.googleapis.com/v1/text:synthesize?key=$apiKey"

        val body = JSONObject().apply {
            put("input", JSONObject().put("text", text))
            put(
                "voice",
                JSONObject()
                    .put("languageCode", languageCode)
                    .put("name", voiceName)
            )
            put(
                "audioConfig",
                JSONObject().put("audioEncoding", "MP3")
            )
        }

        val request = Request.Builder()
            .url(url)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw Exception("Cloud TTS lỗi ${response.code}: $bodyStr")
            }
            val audioContentB64 = JSONObject(bodyStr).getString("audioContent")
            val audioBytes = Base64.decode(audioContentB64, Base64.DEFAULT)

            val outFile = File(context.cacheDir, "tts_output.mp3")
            outFile.writeBytes(audioBytes)
            outFile
        }
    }
}
