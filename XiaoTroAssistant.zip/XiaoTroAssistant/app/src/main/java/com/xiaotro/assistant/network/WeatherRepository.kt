package com.xiaotro.assistant.network

import com.xiaotro.assistant.SimpleLocation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class WeatherInfo(val temperatureC: Double, val conditionText: String)

/**
 * Lấy thời tiết hiện tại từ Open-Meteo — API thời tiết MIỄN PHÍ, KHÔNG cần đăng
 * ký hay xin API key, nên không cần thêm bước cài đặt nào cho người dùng.
 */
class WeatherRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    suspend fun getCurrentWeather(location: SimpleLocation): WeatherInfo = withContext(Dispatchers.IO) {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}" +
            "&longitude=${location.longitude}&current_weather=true"

        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("Lỗi lấy thời tiết: ${response.code}")
            val body = response.body?.string().orEmpty()
            val current = JSONObject(body).getJSONObject("current_weather")
            val temp = current.getDouble("temperature")
            val code = current.getInt("weathercode")
            WeatherInfo(temp, describeWeatherCode(code))
        }
    }

    private fun describeWeatherCode(code: Int): String = when (code) {
        0 -> "trời quang, nắng đẹp"
        1, 2, 3 -> "có mây"
        45, 48 -> "sương mù"
        51, 53, 55, 56, 57 -> "mưa phùn nhẹ"
        61, 63, 65 -> "mưa"
        66, 67 -> "mưa lạnh"
        71, 73, 75, 77 -> "có tuyết"
        80, 81, 82 -> "mưa rào"
        85, 86 -> "mưa tuyết rào"
        95 -> "có dông"
        96, 99 -> "dông kèm mưa đá"
        else -> "thời tiết không xác định rõ"
    }
}
