# Xiao Trợ Lý — App trợ lý ảo giống Xiaozhi cho Android

Trợ lý ảo tiếng Việt: luôn nghe từ khóa đánh thức → ghi âm câu hỏi → gửi lên
Gemini API → đọc câu trả lời to lên. Chạy trên điện thoại Android thật (Android
Studio), không phải web demo.

## Kiến trúc
```
[Mic luôn nghe] → [Porcupine wake word] → [Android SpeechRecognizer]
   → [Gemini 2.5 Flash API] → [Android TextToSpeech] → [Loa]
```

## Bước 1 — Lấy API key (miễn phí)

1. **Gemini API key**: vào https://aistudio.google.com/apikey, đăng nhập Google,
   bấm "Create API key". Free tier ~1500 request/ngày, không cần thẻ tín dụng.
2. **Picovoice Access key** (cho wake word): vào https://console.picovoice.ai,
   đăng ký free, lấy Access Key trong Dashboard.
3. **File từ khóa .ppn**: trong Picovoice Console → mục "Porcupine" → tạo
   custom wake word (gõ ví dụ "Hey Trợ Lý"), chọn platform **Android**, tải
   file `.ppn` về.

## Bước 2 — Nhập key ngay trong app (không cần sửa code)

Build và mở app lên → bấm icon ⚙️ **Cài đặt** ở góc trên bên phải → nhập:
- Gemini API key
- Picovoice access key
- (Tùy chọn) Cloud TTS API key nếu muốn bật giọng đọc chất lượng cao — xem Bước 3b

Bấm **Lưu**. App tự khởi động lại wake-word service với key mới, không cần build lại.

## Bước 3 — Thêm file wake word

Copy file `.ppn` bạn tải ở Bước 1 vào:
```
app/src/main/assets/wakeword_vi_android.ppn
```
(đúng tên trong `Config.WAKE_WORD_ASSET_FILE`, hoặc đổi tên trong Config.kt cho khớp).

**Muốn test nhanh trước khi có file .ppn riêng?** Mở
`WakeWordService.kt`, trong hàm `startPorcupine()`, đổi dòng:
```kotlin
.setKeywordPath(Config.WAKE_WORD_ASSET_FILE)
```
thành:
```kotlin
.setKeyword(Porcupine.BuiltInKeyword.PORCUPINE)
```
để dùng thử từ khóa có sẵn "Porcupine" (tiếng Anh) trong lúc chờ tạo từ khóa
tiếng Việt riêng.

## Bước 3b — (Tùy chọn) Bật giọng đọc chất lượng cao

Mặc định app dùng giọng TextToSpeech có sẵn của Android (miễn phí, không cần key
nhưng hơi khô). Muốn giọng tự nhiên hơn nhiều:

1. Vào https://console.cloud.google.com → tạo project (hoặc dùng project đã tạo
   cho Gemini) → **bật billing** (Google yêu cầu thêm thẻ dù dùng free tier,
   không bị trừ tiền nếu trong hạn mức 1 triệu ký tự/tháng cho giọng WaveNet)
2. Vào **APIs & Services → Enable APIs** → tìm và bật **"Cloud Text-to-Speech API"**
3. Vào **APIs & Services → Credentials** → tạo API key mới
4. Trong app → Cài đặt → bật switch "Dùng giọng chất lượng cao" → dán key vào
   → có thể đổi tên giọng, ví dụ `vi-VN-Wavenet-A` (giọng nữ), `vi-VN-Wavenet-B`
   (giọng nam), `vi-VN-Wavenet-C`, `vi-VN-Neural2-A`

Nếu không muốn tốn công bước này, cứ để tắt — app vẫn chạy đầy đủ chức năng với
giọng Android mặc định.

## Tính năng ngắt lời (barge-in)

Khi trợ lý đang đọc câu trả lời, bạn có thể **ngắt lời** bằng 2 cách:
- Bấm nút mic (lúc này hiện icon ⏹️) — dừng đọc và bắt đầu nghe câu hỏi mới ngay
- Nói lại từ khóa đánh thức — trợ lý tự dừng đọc và chuyển sang nghe

## Lệnh điều khiển nhạc

App nhận diện các câu lệnh sau và xử lý ngay tại máy (không gửi lên Gemini, phản
hồi nhanh hơn), miễn là máy đã cài sẵn 1 app nghe nhạc (YouTube Music, Spotify,
Zing MP3...):

| Nói | Tác dụng |
|---|---|
| "Mở nhạc" / "Phát nhạc" / "Bật nhạc" | Mở app nhạc mặc định, phát ngẫu nhiên |
| "Mở nhạc bài [tên bài hát]" | Yêu cầu app nhạc tìm và phát đúng bài đó |
| "Dừng nhạc" / "Tắt nhạc" | Tạm dừng |
| "Tiếp tục nhạc" | Phát tiếp |
| "Bài tiếp theo" / "Chuyển bài" | Chuyển sang bài kế |
| "Bài trước" | Quay lại bài trước |

Cơ chế: lệnh "mở nhạc" dùng Intent chuẩn của Android
(`INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH`) để hệ thống tự chọn app nhạc mặc định
mở lên — giống hệt cách Google Assistant làm khi bạn nói "OK Google, mở nhạc".
Các lệnh dừng/tiếp tục/chuyển bài mô phỏng nút bấm media vật lý, gửi tới app
nhạc đang chạy nền.

Muốn thêm lệnh khác (bật đèn pin, gọi điện, mở app...) chỉ cần thêm pattern mới
vào `CommandRouter.kt`.

## Lệnh đèn pin, mở app, gọi điện

| Nói | Tác dụng |
|---|---|
| "Bật đèn pin" | Bật đèn flash (không cần quyền Camera) |
| "Tắt đèn pin" | Tắt đèn flash |
| "Mở [tên app]" (ví dụ "Mở Zalo", "Mở Facebook") | Tìm app đã cài theo tên gần đúng và mở lên |
| "Gọi cho [tên trong danh bạ]" | Tìm số trong danh bạ và gọi |
| "Gọi số [số điện thoại]" | Gọi thẳng theo số vừa đọc |

**Về quyền gọi điện:**
- Nếu cấp quyền **Gọi điện thoại (CALL_PHONE)**: app gọi thẳng ngay khi ra lệnh
- Nếu **từ chối quyền này**: app tự chuyển sang mở màn hình quay số có sẵn số
  điện thoại — bạn chỉ cần bấm nút gọi, an toàn hơn (tránh gọi nhầm do nhận
  diện giọng nói sai)
- Lệnh "Gọi cho [tên]" cần thêm quyền **Danh bạ (READ_CONTACTS)** để tra số;
  nếu từ chối, trợ lý sẽ báo chưa có quyền thay vì tự ý làm gì khác

Nếu lỡ từ chối quyền lúc mở app lần đầu, vào **Cài đặt máy → Ứng dụng → Xiao
Trợ Lý → Quyền** để bật lại.

## Camera: chào hỏi tự động + nhận diện khuôn mặt/biểu cảm

Nói **"Mở camera"**, **"Chào tôi đi"**, hoặc **"Nhìn xem ai đây"** — hoặc bấm
icon 📷 trên thanh trên — để mở màn hình camera trước (selfie). App tự động:

1. Phát hiện khuôn mặt và **phân tích biểu cảm** (vui vẻ / buồn ngủ / nghiêm
   túc / bình thường) bằng Google ML Kit Face Detection — chạy on-device,
   miễn phí, không cần setup gì thêm.
2. Sau khi thấy mặt ổn định ~1.5 giây, tự chụp 1 ảnh và gửi ngữ cảnh (biểu cảm
   + kết quả nhận diện danh tính nếu có) cho Gemini để tạo lời chào **tự
   nhiên, phù hợp tâm trạng** — rồi đọc to lên.

### (Tùy chọn) Bật nhận diện "đây có phải chủ nhân không"

Mặc định app CHƯA phân biệt được bạn với người lạ — chỉ phân tích biểu cảm
chung. Muốn bật tính năng "nhớ mặt chủ nhân":

1. Tìm và tải 1 file model **MobileFaceNet dạng `.tflite`** (khoảng 5MB) — đây
   là model mã nguồn mở phổ biến, tìm trên GitHub với từ khóa
   "mobilefacenet tflite android". Cần model nhận input ảnh 112x112 và trả về
   embedding 192 chiều (phổ biến nhất trong các bản convert có sẵn).
2. Đặt file vào `app/src/main/assets/mobilefacenet.tflite`
3. Build lại app → mở Camera → bấm **"Ghi nhớ đây là tôi"** để ghi nhớ khuôn
   mặt của bạn
4. Từ lần sau, khi camera tự chào hỏi, trợ lý sẽ biết đây có phải bạn không

**Giới hạn cần biết:**
- Đây là bản demo đơn giản (không crop/căn chỉnh khuôn mặt chuẩn), độ chính
  xác **không đảm bảo tuyệt đối** — không dùng để bảo vệ dữ liệu nhạy cảm hay
  thay thế khóa màn hình thật
- Chỉ ghi nhớ được **1 khuôn mặt chủ nhân** tại một thời điểm (ghi đè nếu ghi
  nhớ lại)
- Toàn bộ dữ liệu khuôn mặt (embedding) chỉ lưu **cục bộ trên máy**, không gửi
  lên đâu cả — chỉ nên dùng để nhận diện chính bạn, cân nhắc kỹ nếu muốn dùng
  cho người khác (cần sự đồng ý của họ)
- Lần đầu dùng ML Kit Face Detection, máy cần internet để tải model nhận diện
  khuôn mặt (dùng qua Google Play Services), sau đó chạy offline bình thường

## Bước 4 — Mở project và chạy

1. Mở Android Studio (bản mới nhất) → Open → chọn thư mục `XiaoTroAssistant`
2. Đợi Gradle sync xong (lần đầu cần internet để tải dependencies)
3. Cắm điện thoại Android thật (khuyến khích, vì mic + always-listening service
   test trên máy thật chính xác hơn emulator) → bấm Run
4. Cho phép quyền Micro và Thông báo khi app hỏi
5. Nói từ khóa đánh thức bạn đã tạo → nói câu hỏi → nghe trợ lý trả lời

## Ghi chú quan trọng

- **Pin**: always-listening service dùng Porcupine rất nhẹ (thiết kế riêng cho
  việc này) nhưng Android vẫn có thể kill service nền theo thời gian. Vào
  Settings → Apps → Xiao Trợ Lý → Battery → chọn "Không tối ưu hóa/Unrestricted"
  để service không bị hệ thống tắt.
- **STT** dùng `SpeechRecognizer` có sẵn của Android — cần internet và máy có
  Google app cài sẵn (hầu hết máy Android đều có).
- **Chi phí**: toàn bộ stack (Gemini free tier + Porcupine free tier + STT/TTS
  có sẵn của Android) chạy được **miễn phí** trong giới hạn free tier hàng ngày.
- Muốn nâng chất lượng giọng đọc, có thể thay `TextToSpeech` mặc định bằng
  giọng TTS cloud (Google Cloud TTS, ElevenLabs...) — hỏi lại nếu bạn muốn mình
  thêm phần này.

## Cấu trúc project
```
app/src/main/java/com/xiaotro/assistant/
 ├─ Config.kt                 ← hằng số không bí mật (model name, system prompt...)
 ├─ AppPreferences.kt         ← lưu API key/cài đặt nhập từ màn hình Settings
 ├─ MainActivity.kt           ← xin quyền, khởi động service, điều hướng Chat/Settings
 ├─ AssistantViewModel.kt     ← điều phối STT → lệnh cục bộ/Gemini → TTS, xử lý ngắt lời
 ├─ CommandRouter.kt          ← nhận diện lệnh nhạc/đèn pin/mở app/gọi điện, xử lý tại máy
 ├─ FlashlightController.kt   ← bật/tắt đèn flash
 ├─ AppLauncher.kt            ← tìm và mở app theo tên gần đúng
 ├─ PhoneController.kt        ← tra số danh bạ theo tên + thực hiện cuộc gọi
 ├─ FaceMoodAnalyzer.kt       ← phân loại biểu cảm từ kết quả ML Kit Face Detection
 ├─ FaceEmbedder.kt           ← (tùy chọn) nhận diện danh tính qua model MobileFaceNet
 ├─ service/
 │   ├─ WakeWordService.kt    ← foreground service chạy Porcupine liên tục
 │   ├─ AssistantEvents.kt    ← cầu nối sự kiện service ↔ ViewModel
 │   └─ CloudTtsPlayer.kt     ← phát audio Cloud TTS, hỗ trợ stop() để ngắt lời
 ├─ network/
 │   ├─ GeminiRepository.kt   ← gọi Gemini REST API, giữ lịch sử hội thoại
 │   └─ CloudTtsRepository.kt ← gọi Google Cloud Text-to-Speech (giọng WaveNet)
 └─ ui/
     ├─ ChatScreen.kt              ← giao diện Compose (khung chat + nút mic/ngắt lời)
     ├─ SettingsScreen.kt          ← nhập API key, bật/tắt giọng chất lượng cao, xoá dữ liệu mặt
     └─ CameraGreetingScreen.kt    ← preview camera + phát hiện mặt/biểu cảm + tự chào hỏi
```
