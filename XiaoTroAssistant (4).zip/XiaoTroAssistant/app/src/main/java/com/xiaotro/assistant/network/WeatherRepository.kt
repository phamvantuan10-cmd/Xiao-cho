package com.xiaotro.assistant.network

import com.xiaotro.assistant.SimpleLocation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class WeatherInfo(val temperatureC: Double, val conditionText: String)

data class DayForecast(
    val date: String, // dạng yyyy-MM-dd
    val minC: Double,
    val maxC: Double,
    val conditionText: String,
    val rainChancePercent: Int?
)

data class WeatherReport(val current: WeatherInfo, val days: List<DayForecast>)

/**
 * Lấy thời tiết hiện tại + dự báo 7 ngày từ Open-Meteo — dịch vụ MIỄN PHÍ,
 * KHÔNG cần đăng ký hay xin API key, nên không cần thêm bước cài đặt nào.
 */
class WeatherRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun getReport(location: SimpleLocation): WeatherReport = withContext(Dispatchers.IO) {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}" +
            "&longitude=${location.longitude}&current_weather=true" +
            "&daily=weathercode,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
            "&timezone=auto&forecast_days=7"

        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("Lỗi lấy thời tiết: ${response.code}")
            val root = JSONObject(response.body?.string().orEmpty())

            val cur = root.getJSONObject("current_weather")
            val current = WeatherInfo(cur.getDouble("temperature"), describeWeatherCode(cur.getInt("weathercode")))

            val daily = root.getJSONObject("daily")
            val times = daily.getJSONArray("time")
            val codes = daily.getJSONArray("weathercode")
            val maxs = daily.getJSONArray("temperature_2m_max")
            val mins = daily.getJSONArray("temperature_2m_min")
            val rain = daily.optJSONArray("precipitation_probability_max")

            val days = (0 until times.length()).map { i ->
                DayForecast(
                    date = times.getString(i),
                    minC = mins.getDouble(i),
                    maxC = maxs.getDouble(i),
                    conditionText = describeWeatherCode(codes.getInt(i)),
                    rainChancePercent = if (rain == null || rain.isNull(i)) null else rain.getInt(i)
                )
            }
            WeatherReport(current, days)
        }
    }

    private fun describeWeatherCode(code: Int): String = when (code) {
        0 -> "trời quang, nắng đẹp"
        1, 2, 3 -> "có mây"
        45, 48 -> "sương mù"
        51, 53, 55, 56, 57 -> "mưa phùn nhẹ"
        61, 63, 65 -> "mưa"
        66, 67 -> "mưa lạnh"
        71, 73, 75, 77 -> "có tuyết"
        80, 81, 82 -> "mưa rào"
        85, 86 -> "mưa tuyết rào"
        95 -> "có dông"
        96, 99 -> "dông kèm mưa đá"
        else -> "thời tiết không xác định rõ"
    }
}
